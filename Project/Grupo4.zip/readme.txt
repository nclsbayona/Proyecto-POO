Grupo 4:
Alejandro Sacristan
Andrés Porras
Juan Sebastian Herrera
Nicolás Bayona
Jesus Alvarez
